﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GigueService.Models
{
    public class Rating
    {
        public int RatingId { get; set; }
        public string MusicianRating { get; set; }
    }
}